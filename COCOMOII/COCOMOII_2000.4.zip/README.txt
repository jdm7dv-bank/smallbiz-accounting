
COCOMO II version 2000.3
Copyright (c) 2002 Univerity of Southern California Center for Software
Engineering.  All rights reserved.

This software was developed by the Center for Software Engineering at the
University of Southern California (USC).  Redistribution and use in source
and binary forms are permitted provided that the above copyright notice
and this paragraph are duplicated in all such forms and that any
documentation, advertising materials, and other materials related to such
distribution and use acknowledge that the software was developed by the
USC Center for Software Engineering.  The name of the University of
Southern California or Center for Software Engineering may not be used to 
endorse or promote products derived from this software without specific 
prior written permission.  THIS SOFTWARE IS PROVIDED 'AS IS' AND WITHOUT 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE 
IMPLIED WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR 
PURPOSE.

I. System and Hardware Requirements

	Higher than Pentium II processor
	Higher than 32 RAM and 10M HDD space
	Window 95/98/NT/2000/XP

II. Features (From COCOMO II 1999 version)

	Windows98/NT/2000/XP Platform Support
	Phase Distribution
	Waterfall Model & MBASE/RUP
	Extended FP Backfire Table
	Extend FP calculation 
	Change of Acronyms
	PEXP?PLEX, AEXP?APEX, and BRAK? REVL
	Adjustable Cost Drivers
	COCOMO II Book Published in July, 2000
	Update Interface(main screen)

III. Release Notes  

	New Function Point Ratio added (David Consulting Group)

IV. Problem Reports

	Send Mail to keunlee@sunset.usc.edu with Information below
	Error Description, Detector Name, Contact Info, Date.

V. References

	website : sunset.usc.edu
	contact info : Keun Lee (213 740 6506) keunlee@sunset.usc.edu


        
        University of Southern California
        Center for Software Engineering
        941 W. 37th Place, SAL Room 328
        Los Angeles, CA 90089-0781
        Tel:(213)740-5703
        Website: http://cse.usc.edu
=====================================================================